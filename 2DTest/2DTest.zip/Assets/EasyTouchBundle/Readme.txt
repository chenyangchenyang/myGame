**********************************************
				EASY TOUCH 4
				
Copyright © 2015 The Hedgehog Team
http://www.blitz3dfr.com/teamtalk/index.php

		the.hedgehog.team@gmail.com

**********************************************

EasyTouch Bundle 4.2.2
***********************
EasyTouch => 4.0.4 
EasyTouch Controls => EasyTouchControls 1.2.2

EasyTouch Bundle 4.2.1
***********************
EasyTouch => 4.0.4 
EasyTouch Controls => EasyTouchControls 1.2.1


EasyTouch Bundle 4.2.0
***********************
EasyTouch => 4.0.4 
EasyTouch Controls => EasyTouchControls 1.2.0


Thank you for your purchase!

If you have any questions, suggestions, please
use the Hedgehog Team Community forum,  here: http://www.blitz3dfr.com/teamtalk/index.php

Or send us an email at : the.hedgehog.team@gmail.com

If you like EasyTouch, don't forget a write a review on the asset store :-)

***********
* WARNING *
***********
EasyTouch 4 comes with a lot of new features, which can not be compatible with the version 3.1.X.

Make migration that if you create a new project

features no longer supported
-----------------------------
* EasyJoystick & EasyButton are no longer supported, they are replaced by Easy Touch Controls
* Reserved area are no longer supported, the new Unity UI is more flexible
* Message sending via the internal management system in Unity for javascript user has been replaced by the component EasyTouchTrigger.

