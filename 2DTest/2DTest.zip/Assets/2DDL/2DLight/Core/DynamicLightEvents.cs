﻿namespace DynamicLight2D{
	using UnityEngine;
	using UnityEngine.Events;
	using System.Collections;
	using System;
	
	[Serializable]
	public class DynamicLightEvent : UnityEvent<GameObject>{}

}

