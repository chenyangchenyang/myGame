﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.IO;
using DynamicLight2D;

[CustomEditor (typeof (AddOnBase))] 
public class AddOnBaseEditor : Editor {

	// Use this for initialization

	

}
